console.log('background script executed');
